﻿**Praktikum Object Oriented Programming Jobsheet 1** 

![](Aspose.Words.1f384da2-6a12-4946-b0bf-f68dcb7505d5.001.png)

**Nama: Riski Abdi Rahmawan NIM: 2241720060** 

**Kelas: 2E** 

**Absen: 25** 

**POLITEKNIK NEGERI MALANG** 

**Jl. Soekarno Hatta No.9, Jatimulyo, Kec. Lowokwaru, Kota Malang, Jawa Timur** 

**65141** 

![](Aspose.Words.1f384da2-6a12-4946-b0bf-f68dcb7505d5.002.png)

Jawab: 

1. Objek adalah suatu benda nyata yang lebih spesifik. Sedangkan class adalah gambaran umum dari suatu benda nyata. 
1. karena nantinya pada setiap mobil bisa saja memiliki warna dan tipe mesin yang berbeda- beda. 
1. dapat menghemat penggunaan variable serta meminimalisir duplikat variabel. 
1. boleh 
1. karena class sepedagunung merupakan warisan dari class sepeda sehingga dapat mengakses attribute yang terdapat pada class sepeda. 

![](Aspose.Words.1f384da2-6a12-4946-b0bf-f68dcb7505d5.003.jpeg)

Jawab:  1.   

- Kompor listrik 

![](Aspose.Words.1f384da2-6a12-4946-b0bf-f68dcb7505d5.004.jpeg)

- Kompor gas 

![](Aspose.Words.1f384da2-6a12-4946-b0bf-f68dcb7505d5.005.jpeg)

- Setrika 

![](Aspose.Words.1f384da2-6a12-4946-b0bf-f68dcb7505d5.006.png)

- Lampu 

![](Aspose.Words.1f384da2-6a12-4946-b0bf-f68dcb7505d5.007.png)

2\.   

- Kompor Listrik 
- Attribute: 
  - Waktu 
  - Daya 
- Method: 
1. mengaturWaktu() 
1. mengaturDaya() 
1. cekKomporListrik() 
- Kompor Gas 
- Attribute: 
  - Jenis Pengatur Suhu 
  - Jenis Piringan 
- Method: 
1. setJenisPengaturSuhu() 
1. setJenisPiringan() 
1. cekKomporGas() 
- Setrika  
- Attribute: 
  - Merek 
  - Warna 
  - Kondisi 
  - Suhu 
- Method 
1. setMerek() 
1. setWarna() 
1. menyala() 
1. mati() 
1. menambahSuhu() 
1. mengurangiSuhu() 
1. cekSetrika() 
- Lampu 
- Attribute: 
  - Merek 
  - Warna Cahaya 
  - Bentuk 
  - Kondisi 
- Method 
1. setMerek() 
1. setWarnaCahaya() 
1. setBentuk() 
1. menyala() 
1. mati() 

 
- kompor listrik 

![](Aspose.Words.1f384da2-6a12-4946-b0bf-f68dcb7505d5.008.jpeg)

- kompor gas 

![](Aspose.Words.1f384da2-6a12-4946-b0bf-f68dcb7505d5.009.jpeg)

- setrika 

![](Aspose.Words.1f384da2-6a12-4946-b0bf-f68dcb7505d5.010.jpeg)


![](Aspose.Words.1f384da2-6a12-4946-b0bf-f68dcb7505d5.011.png)

- lampu 

![](Aspose.Words.1f384da2-6a12-4946-b0bf-f68dcb7505d5.012.jpeg)

 
- class kompor 

![](Aspose.Words.1f384da2-6a12-4946-b0bf-f68dcb7505d5.013.jpeg)

![](Aspose.Words.1f384da2-6a12-4946-b0bf-f68dcb7505d5.014.jpeg)

5\.   

- instansiasi objek serta penggunaan method pada class kompor 

![](Aspose.Words.1f384da2-6a12-4946-b0bf-f68dcb7505d5.015.png)


![](Aspose.Words.1f384da2-6a12-4946-b0bf-f68dcb7505d5.016.png)

- instansiasi objek serta penggunaan method pada class komporlistrik 

![](Aspose.Words.1f384da2-6a12-4946-b0bf-f68dcb7505d5.017.png)

![](Aspose.Words.1f384da2-6a12-4946-b0bf-f68dcb7505d5.018.png)

- instansiasi objek serta penggunaan method pada class kompor gas 

![](Aspose.Words.1f384da2-6a12-4946-b0bf-f68dcb7505d5.019.png)

![](Aspose.Words.1f384da2-6a12-4946-b0bf-f68dcb7505d5.020.png)

- instansiasi objek serta penggunaan method pada class setrika 

![](Aspose.Words.1f384da2-6a12-4946-b0bf-f68dcb7505d5.021.png)

![](Aspose.Words.1f384da2-6a12-4946-b0bf-f68dcb7505d5.022.png)

- instansiasi objek serta penggunaan method pada class lampu 

![](Aspose.Words.1f384da2-6a12-4946-b0bf-f68dcb7505d5.023.png)

![](Aspose.Words.1f384da2-6a12-4946-b0bf-f68dcb7505d5.024.png)
